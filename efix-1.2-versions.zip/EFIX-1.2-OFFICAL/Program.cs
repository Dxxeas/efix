﻿using System;
using System.IO;
using System.Linq;

namespace EFIX_1_2
{
    class Program
    {
        private static readonly string directoryPath = @"C:\Users\dxxea\source\repos\EFIX\EFIX";
        private static readonly string activationFilePath = Path.Combine(directoryPath, "activation.dat");

        static void Main(string[] args)
        {
            // Display the welcome message
            ShowWelcomeMessage();

            // Command handling loop
            while (true)
            {
                // Display the prompt
                Console.Write("efix.efi> ");
                string input = Console.ReadLine();

                // Process the input command
                ProcessCommand(input);
            }
        }

        static void ShowWelcomeMessage()
        {
            Console.Clear(); // Clear the console before showing the message
            if (File.Exists(activationFilePath))
            {
                Console.WriteLine("EFIX 1.2 Pro, Console App.");
                Console.WriteLine("Official version, Safe.");
            }
            else
            {
                Console.WriteLine("EFIX 1.2, Console App.");
                Console.WriteLine("Official version, Safe.");
            }
            Console.WriteLine();
        }

        static void ProcessCommand(string input)
        {
            // Split the input into command and argument
            string[] parts = input.Split(' ');

            if (parts.Length > 0)
            {
                string command = parts[0].ToLower();

                switch (command)
                {
                    case "classroot":
                        if (parts.Length == 2)
                        {
                            string fileName = parts[1].ToLower();
                            string filePath = Path.Combine(directoryPath, fileName);

                            // Debug output to check the path
                            Console.WriteLine($"Checking file path: {filePath}");

                            // Check if the file exists
                            if (File.Exists(filePath))
                            {
                                Console.WriteLine($"{fileName} is enabled.");
                            }
                            else
                            {
                                Console.WriteLine($"{fileName} not found.");
                            }
                        }
                        else
                        {
                            Console.WriteLine("Usage: classRoot <filename>");
                        }
                        break;

                    case "about.efix":
                        Console.WriteLine("EFIX 1.2 Pro, Console Application");
                        Console.WriteLine("This is a version with safe features.");
                        break;

                    case "showcode":
                        if (parts.Length == 2)
                        {
                            string filePath = parts[1];

                            // Check if the file exists
                            if (File.Exists(filePath))
                            {
                                Console.WriteLine($"Displaying contents of {Path.GetFileName(filePath)}:");
                                Console.WriteLine(File.ReadAllText(filePath));
                            }
                            else
                            {
                                Console.WriteLine($"{Path.GetFileName(filePath)} not found.");
                            }
                        }
                        else
                        {
                            Console.WriteLine("Usage: showCode <path to file>");
                        }
                        break;

                    case "efix":
                        if (parts.Length == 2 && parts[1].ToLower() == "showdata")
                        {
                            ShowData();
                        }
                        else
                        {
                            Console.WriteLine("Usage: efix showData");
                        }
                        break;

                    case "activatepro":
                        ActivateProVersion();
                        break;

                    case "disactivatepro":
                        DeactivateProVersion();
                        break;

                    default:
                        Console.WriteLine("Unknown command.");
                        break;
                }
            }
            else
            {
                Console.WriteLine("No command entered.");
            }
        }

        static void ShowData()
        {
            // Generate and display random data
            Random rand = new Random();
            for (int i = 0; i < 10; i++)
            {
                string dataLine = string.Join(" ", Enumerable.Range(0, 10).Select(_ => $"{(char)('A' + rand.Next(0, 26))}{rand.Next(0, 10)}"));
                Console.WriteLine(dataLine);
            }
        }

        static void ActivateProVersion()
        {
            // Check if the pro version is already activated
            if (File.Exists(activationFilePath))
            {
                Console.WriteLine("Pro version is already activated.");
                return;
            }

            Console.WriteLine("Enter key for activate pro version.");
            Console.WriteLine("For cancel write: Cancel.");
            Console.Write(">");

            string key = Console.ReadLine();

            if (key.Equals("Cancel", StringComparison.OrdinalIgnoreCase))
            {
                Console.WriteLine("Activation canceled.");
                return;
            }

            // Define the correct activation key
            const string correctKey = "Y5693-F5329-48HJD-4JF9S-F43J4";

            if (key == correctKey)
            {
                // Save activation state
                File.Create(activationFilePath).Close();
                Console.WriteLine("Pro version activated successfully.");
                ShowWelcomeMessage(); // Update welcome message
            }
            else
            {
                Console.WriteLine("Invalid activation key.");
            }
        }

        static void DeactivateProVersion()
        {
            // Check if the pro version is activated
            if (!File.Exists(activationFilePath))
            {
                Console.WriteLine("Pro version is not activated.");
                return;
            }

            // Remove the activation file
            File.Delete(activationFilePath);
            Console.WriteLine("Pro version deactivated successfully.");
            ShowWelcomeMessage(); // Update welcome message
        }
    }
}
