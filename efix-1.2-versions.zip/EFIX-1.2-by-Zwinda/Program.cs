﻿using System;
using System.IO;
using System.Linq;

namespace EFIX_1_0
{
    class Program
    {
        private static readonly string activationKey = "Y5693-F5329-48HJD-4JF9S-F43J4"; // Предопределённый ключ активации
        private static bool isProVersion = false;

        static void Main(string[] args)
        {
            // Display the welcome message
            ShowWelcomeMessage();

            // Command handling loop
            while (true)
            {
                // Display the prompt with the prefix
                Console.Write(isProVersion ? "efixPro.efi> " : "efix.efi> ");
                string input = Console.ReadLine();

                // Process the input command
                ProcessCommand(input);
            }
        }

        static void ShowWelcomeMessage()
        {
            Console.Clear(); // Clear the console before showing the message
            Console.WriteLine(isProVersion ? "EFIX 1.2 Pro, Console App." : "EFIX 1.2, Console App.");
            Console.WriteLine("Official version, Safe.");
            Console.WriteLine();
        }

        static void ProcessCommand(string input)
        {
            // Split the input into command and argument
            string[] parts = input.Split(' ');

            if (parts.Length > 0)
            {
                string command = parts[0].ToLower();
                string directoryPath = @"C:\Users\dxxea\source\repos\EFIX\EFIX";

                switch (command)
                {
                    case "classroot":
                        if (parts.Length == 2)
                        {
                            string fileName = parts[1].ToLower();
                            string filePath = Path.Combine(directoryPath, fileName);

                            // Debug output to check the path
                            Console.WriteLine($"Checking file path: {filePath}");

                            // Check if the file exists
                            if (File.Exists(filePath))
                            {
                                Console.WriteLine($"{fileName} is enabled.");
                            }
                            else
                            {
                                Console.WriteLine($"{fileName} not found.");
                            }
                        }
                        else
                        {
                            Console.WriteLine("Usage: classRoot <filename>");
                        }
                        break;

                    case "about.efix":
                        Console.WriteLine("EFIX 1.2, Console Application");
                        Console.WriteLine("This is an official version with safe features.");
                        break;

                    case "showcode":
                        if (parts.Length == 2)
                        {
                            string fileName = parts[1].ToLower();
                            string filePath = Path.Combine(directoryPath, fileName);

                            // Check if the file exists
                            if (File.Exists(filePath))
                            {
                                Console.WriteLine($"Displaying contents of {fileName}:");
                                Console.WriteLine(File.ReadAllText(filePath));
                            }
                            else
                            {
                                Console.WriteLine($"{fileName} not found.");
                            }
                        }
                        else
                        {
                            Console.WriteLine("Usage: showCode <filename>");
                        }
                        break;

                    case "efix":
                        if (parts.Length == 2 && parts[1].ToLower() == "showdata")
                        {
                            ShowData();
                        }
                        else
                        {
                            Console.WriteLine("Unknown command or incorrect usage.");
                        }
                        break;

                    case "activatepro":
                        ActivateProVersion();
                        break;

                    default:
                        Console.WriteLine("Unknown command.");
                        break;
                }
            }
            else
            {
                Console.WriteLine("No command entered.");
            }
        }

        static void ShowData()
        {
            Random rand = new Random();
            string GenerateRandomData()
            {
                char letter = (char)rand.Next('A', 'Z' + 1);
                int number = rand.Next(0, 10);
                return $"{letter}{number}";
            }

            Console.WriteLine("EFIX Data:");
            for (int i = 0; i < 10; i++)
            {
                Console.WriteLine(string.Join(" ", Enumerable.Range(0, 10).Select(_ => GenerateRandomData())));
            }
        }

        static void ActivateProVersion()
        {
            Console.WriteLine("Enter key for activate pro version.");
            Console.WriteLine("For cancel write: Cancel.");
            Console.Write("> ");
            string input = Console.ReadLine();

            if (input.Equals("Cancel", StringComparison.OrdinalIgnoreCase))
            {
                Console.WriteLine("Activation canceled.");
                return;
            }

            if (input == activationKey)
            {
                isProVersion = true;
                Console.Clear(); // Clear the console to show the new welcome message
                ShowWelcomeMessage();
            }
            else
            {
                Console.WriteLine("Invalid key. Activation failed.");
            }
        }
    }
}
