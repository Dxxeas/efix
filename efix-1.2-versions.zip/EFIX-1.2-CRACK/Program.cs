﻿using System;
using System.IO;

namespace EFIX_1_2_Crack
{
    class Program
    {
        private static readonly string directoryPath = @"C:\Users\dxxea\source\repos\EFIX\EFIX";

        static void Main(string[] args)
        {
            // Display the welcome message
            ShowWelcomeMessage();

            // Command handling loop
            while (true)
            {
                // Display the prompt with the prefix for cracked version
                Console.Write("efix.efi> ");
                string input = Console.ReadLine();

                // Process the input command
                ProcessCommand(input);
            }
        }

        static void ShowWelcomeMessage()
        {
            Console.Clear(); // Clear the console before showing the message
            Console.WriteLine("EFIX 1.2 Pro, Console App.");
            Console.WriteLine("Crack version, Unsafe.");
            Console.WriteLine();
        }

        static void ProcessCommand(string input)
        {
            // Split the input into command and argument
            string[] parts = input.Split(' ');

            if (parts.Length > 0)
            {
                string command = parts[0].ToLower();

                switch (command)
                {
                    case "classroot":
                        if (parts.Length == 2)
                        {
                            string fileName = parts[1].ToLower();
                            string filePath = Path.Combine(directoryPath, fileName);

                            // Debug output to check the path
                            Console.WriteLine($"Checking file path: {filePath}");

                            // Check if the file exists
                            if (File.Exists(filePath))
                            {
                                Console.WriteLine($"{fileName} is enabled.");
                            }
                            else
                            {
                                Console.WriteLine($"{fileName} not found.");
                            }
                        }
                        else
                        {
                            Console.WriteLine("Usage: classRoot <filename>");
                        }
                        break;

                    case "about.efix":
                        Console.WriteLine("EFIX 1.2 Pro, Console Application");
                        Console.WriteLine("This is a crack version with unsafe features.");
                        break;

                    case "showcode":
                        if (parts.Length == 2)
                        {
                            string filePath = parts[1];

                            // Check if the file exists
                            if (File.Exists(filePath))
                            {
                                Console.WriteLine($"Displaying contents of {Path.GetFileName(filePath)}:");
                                Console.WriteLine(File.ReadAllText(filePath));
                            }
                            else
                            {
                                Console.WriteLine($"{Path.GetFileName(filePath)} not found.");
                            }
                        }
                        else
                        {
                            Console.WriteLine("Usage: showCode <path to file>");
                        }
                        break;

                    case "efix":
                        if (parts.Length == 2 && parts[1].ToLower() == "showdata")
                        {
                            ShowData();
                        }
                        else
                        {
                            Console.WriteLine("Usage: efix showData");
                        }
                        break;

                    default:
                        Console.WriteLine("Unknown command.");
                        break;
                }
            }
            else
            {
                Console.WriteLine("No command entered.");
            }
        }

        static void ShowData()
        {
            // Generate and display random data
            Random rand = new Random();
            for (int i = 0; i < 10; i++)
            {
                string dataLine = string.Join(" ", Enumerable.Range(0, 10).Select(_ => $"{(char)('A' + rand.Next(0, 26))}{rand.Next(0, 10)}"));
                Console.WriteLine(dataLine);
            }
        }
    }
}
